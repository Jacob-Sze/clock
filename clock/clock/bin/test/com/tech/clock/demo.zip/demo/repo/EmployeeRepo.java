package com.tech.clock.demo.repo;
import java.util.List;
import java.util.Optional;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import com.tech.clock.demo.model.Employee;

@Repository
public interface EmployeeRepo extends MongoRepository<Employee, Long> {

    void deleteEmployeeById(Long id);

    Optional<Employee> findEmployeeById(Long id);

    Employee findItemById(Long id);

    List<Employee> findAll(Long id);

    public long count();

}
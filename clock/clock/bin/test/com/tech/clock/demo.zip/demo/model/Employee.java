package com.tech.clock.demo.model;

import java.io.Serializable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document("clockindb")
public class Employee implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(nullable = false, updatable = false)

    private Long id;
    private String name;

    public Employee() {}
    public Employee(String name) {
        this.name=name;
    }
    public Long getId() { return id; }
    public void setId(Long id) { this.id=id; }

    public String getName() { return name; }
    public void setName(String name) { this.name=name; }

    public String toString() {
        return "Employee{id="+id+", name="+name;
    }
}
